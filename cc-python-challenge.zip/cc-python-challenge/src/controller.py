class ControllerInterface:
    pass
